﻿function show() {
    // Get Values
    var user = $("#user-tf").val()
    var pass = $("#pass-tf").val()

    // Alert
    alert("--- Your Input ---\nUser: " + user + "\nPass: " + pass);
}