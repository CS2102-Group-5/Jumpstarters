﻿$(function () {
    $('#creator').on('click', function () {
        $('#preferences').hide();
        $('#organization').show();
    });
    $('#funder').on('click', function () {
        $('#preferences').show();
        $('#organization').hide();
    });

});