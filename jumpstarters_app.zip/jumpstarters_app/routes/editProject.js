var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* SQL Query */
var sql_project = 'UPDATE Projects SET '
var sql_history = 'INSERT INTO History VALUES('

var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

/* GET home page. */
router.get('/', redirectLogin, function (req, res, next) {
    // Check if user is logged in
    //check if user is a creator 
    var user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');
    var sql_creator = "SELECT COUNT(*) FROM Creator WHERE user_name = '" + user_name + "';";
    pool.query(sql_creator, (err, data) => {
        if (err) {
            console.log(err);
            res.send(500, {error:err.toString()})
        } else {
            var is_creator = data.rows[0].count;
            if (is_creator != 1) {
                console.log('You are not a creator');
                res.redirect('/');
            } else {
                var project_info_sql = "SELECT * FROM Projects p INNER JOIN History h ON h.project_id = p.id WHERE (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND p.id = " + id;
                pool.query(project_info_sql, (err, data) => {
                    if (err) {
                        console.log(err);
                        res.send(500, { error: err.toString() })
                    } else {
                        console.log(data.rows)
                        res.render('editProject', { title: 'Edit Project',data:data.rows[0], login: req.session.user_name });
                    }
                })
                
            }
        }
    });
});

/* POST */
router.post('/', function (req, res, next) {    
    var user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');

    // Retrieve Information
    console.log('In post');
    //Need to get Creator user_name
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var projectName = "project_name = '" + req.body.projectName.replace(/'/, "''") + "'";   
    var projectType = "project_type = '" + req.body.projectType + "'";
    var description = "project_description = '" + req.body.description + "'";
    
    var end = req.body.projectEnd;
    var goal = req.body.goal;
    var sql_project_new = sql_project + projectName + "," + projectType + "," + description + " WHERE id = " + id + " AND user_name = '" + user_name + "';";
    var sql_history_new = sql_history + id + ",'Ongoing','" + end + "'," + goal + ",'" + dateTime + "');";

    var sql_query = "BEGIN;" + sql_project_new + sql_history_new + "COMMIT;"
    console.log(sql_query)
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err);
            res.send(500, { error: err.toString() })
            //res.redirect('back')
        } else { 
            console.log('updated database')
            res.redirect('/users')
        }
    });
   
    
});

module.exports = router;
