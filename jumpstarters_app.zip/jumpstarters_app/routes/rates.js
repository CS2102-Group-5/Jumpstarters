﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* SQL Query */
var sql_insert_rates = "INSERT INTO Rates VALUES('";

//redirect 
var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

/* POST */
router.post('/', redirectLogin, function (req, res, next) {
    var user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    var id = Url.searchParams.get('id');
    console.log(user_name)
    console.log(Url)
    sql_query = sql_insert_rates + user_name + "'," + id + "," + req.body.optradio + ");";
    previous_Url = '/viewProject?id=' + id
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err);
            req.session.refresh = true;
            res.send(500, {error:err.toString()})
            //res.redirect(previous_Url);
        } else {
            console.log('Updated database');
            req.session.refresh = true;
            res.redirect(previous_Url);
        }
    });
});

module.exports = router;