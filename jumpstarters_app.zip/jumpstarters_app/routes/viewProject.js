﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

//TODO: If logged in, and already follow/pledge cancel pledge and unfollow project

//increment view
var increment_view = (req, res, next) => {
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');
    console.log(req.session);
    // page is refreshed, do not increment views
    if (req.session.refresh) {
        next();
    } else {
        //sql
        //increment view 
        update_sql = "UPDATE Projects SET num_of_views = num_of_views + 1 WHERE id = " + id;
        pool.query(update_sql, (err, data) => {
            if (err) {
                console.log(err);
                res.send(500, { error: err.toString() })
            } else {
                console.log('views updated');
                req.session.refresh = false;
                //console.log(req.session);
                next();
            }
        })
    }
}

/* GET home page. */
router.get('/', increment_view, function (req, res, next) {
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');

    user_name = req.session.user_name;
    
    /* SQL Query */
    var sql_details = 'SELECT * FROM Projects WHERE id = ' + id + ';';
    var sql_media = 'SELECT link, description FROM Media WHERE project_id = ' + id + 'ORDER BY description;';
    /** Get latest history */
    var sql_history = 'select h.*, extract(day from (h.end_date  - CURRENT_TIMESTAMP)) as days_to_go from history h WHERE (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND h.project_id = ' + id + ';';
    var sql_shipping_info = 'select * from shipping_info WHERE project_id = ' + id + ';';
    var sql_total_pledge = 'select COALESCE(SUM(pledge),0) AS total_pledge, COUNT(*) AS backers FROM Pledges WHERE project_id = ' + id + ';';
    var sql_comments = 'select * from Comments WHERE project_id = ' + id + 'ORDER BY time_stamp DESC LIMIT(5);';
    var sql_tags = 'select tag_name from tags WHERE project_id = ' + id + ';';
    var sql_currencies = 'select currency_name as cur FROM Country ORDER BY currency_name'
    var sql_rates_check = " ";
    var sql_pledge_check = " ";
    var sql_follow_check = " ";
    
    //Check if user has already pledged or followed
    if (user_name) {
        sql_pledge_check = "SELECT pledge FROM Pledges WHERE user_name = '" + user_name + "' AND project_id = " + id 
        sql_follow_check = "SELECT true FROM Follows WHERE funder = '" + user_name + "' AND projects_followed = " + id
        sql_rates_check = "select rating FROM rates WHERE project_id = " + id + "AND user_name = '" + user_name + "'";
        //console.log(sql_pledge_check)
        //console.log(sql_follow_check)
    }

    pool.query(sql_details, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            //remove last character
            var result = JSON.stringify(data.rows[0]).slice(0, -1) + ',';
            var out = merge(sql_history, sql_media, sql_shipping_info, sql_total_pledge, sql_comments, sql_tags, sql_pledge_check, sql_follow_check, sql_rates_check);
            out.then(function (value) {
                pool.query(sql_currencies, (err, data1) => {
                    if (err) {
                        res.send(500, { error: err.toString() })
                    } else {
                        result = result + value + "}";
                        console.log(JSON.parse(result));
                        req.session.refresh = false;
                        res.render('viewProject', { data: JSON.parse(result), currencies: data1.rows, login: req.session.user_name });
                    }
                })
            }) 
        }
    });
});

/* SQL Query */
var sql_insert_pledge = 'INSERT INTO Pledges VALUES(';
var sql_insert_follow = 'INSERT INTO Follows VALUES(';
var sql_delete_pledge = "DELETE FROM Pledges WHERE user_name = '";
var sql_delete_follow = "DELETE FROM Follows WHERE funder = '";

//redirect 
var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

/* POST */
router.post('/', redirectLogin, function (req, res, next) {
    var user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    var id = Url.searchParams.get('id');

    // Retrieve Information
    console.log('In post');
    console.log(user_name);
    console.log(id);
    
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var pledge = req.body.amount;
    var follow = req.body.follow;
    var unfollow = req.body.unfollow;
    var cancel = req.body.cancel;
    var currency = req.body.currencies;

    console.log("pledge:" + pledge)
    console.log("follow:" + follow)
    console.log("unfollow:" + unfollow)
    console.log("cancel:" + cancel)

    //SQL  
    if (pledge) {
        //TODO Convert currency to USD before insertion
        var sql_query = sql_insert_pledge + id + ",'" + user_name + "'," +"(select exchange_rate FROM currencypair where base_currency ='" + currency + "' AND quote_currency = 'USD')*" + pledge + ",'" + dateTime + "');";
        console.log(sql_query)
    }
    if (follow) {
        var sql_query = sql_insert_follow + id + ",'" + user_name + "');";
    }
    if (cancel) {
        var sql_query = sql_delete_pledge + user_name + "' AND project_id  = " + id;
    }
    if (unfollow) {
        var sql_query = sql_delete_follow + user_name + "' AND projects_followed = " + id;
    }

    console.log(sql_query)

    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err);
            req.session.refresh = true;
            res.send(500, {error: err.toString()})
        } else {
            console.log('Updated database');
            req.session.refresh = true;
            res.redirect('back');
        }
    });
});

module.exports = router;


/** FUNCTIONS */

// returns string 
function generate_json(pool, sql, table=undefined) {
    return new Promise((resolve, reject) => {
        pool.query(sql, (err, data) => {
            if (err) {
                console.log(err)
                reject(err);
            } else {
                if (table == undefined) {
                    resolve(JSON.stringify(data.rows)[0]);
                } else {
                    resolve('"' + table + '": ' + JSON.stringify(data.rows));
                }
            }
        });
    });
}

async function merge(sql_h, sql_m, sql_s, sql_t, sql_c, sql_ta, sql_pl = " ", sql_fo = " ", sql_ra = " ") {
    h = await generate_json(pool, sql_h, 'history');
    m = await generate_json(pool, sql_m, 'media');
    s = await generate_json(pool, sql_s, 'shipping');
    t = await generate_json(pool, sql_t, 'total_pledge');
    c = await generate_json(pool, sql_c, 'comments');
    tags = await generate_json(pool, sql_ta, 'tags');
    pl = await generate_json(pool, sql_pl, 'pledges');
    fo = await generate_json(pool, sql_fo, 'follows');
    ra = await generate_json(pool, sql_ra, 'rates');
    //join 
    return h + ',' + m + ',' + s + ',' + t + ',' + c + ',' + tags + ',' + pl + ',' + fo + ',' + ra;
}
