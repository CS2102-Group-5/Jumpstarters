﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})


var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

//TODO cannot delete due to foreign key constraint in pledges
router.post('/', redirectLogin, (req, res, next) => {
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');
    user_name = req.session.user_name
    //sql  
    var sql_query = "DELETE FROM Projects WHERE id = " + id + " AND user_name = '" + user_name + "';"
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err)
            res.send(500, { error: err.toString() })
        } else {
            console.log('updated database');
            res.redirect('/users')
        }
    });
})

module.exports = router;
