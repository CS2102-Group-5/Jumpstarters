﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* GET home page. */
router.get('/', function (req, res, next) {
    user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    console.log(decodeURIComponent(Url))
    var out;
    project_types = Url.searchParams.getAll('project_type[]');
    project_ids = Url.searchParams.getAll('projects[]')
    //format out for project_type
    console.log(project_types)
    out = '{"type":['
    for (var i = 0; i < project_types.length; i++) {
        if (i == project_types.length - 1) {
            out = out + '{"name":"' + project_types[i] + '", "url":"' + project_types[i].replace('&', '%26') + '"}';
        } else {
            out = out + '{"name":"' + project_types[i] + '", "url":"' + project_types[i].replace('&', '%26') + '"},';
        }
        
    }
    out += ']'

    //sql to get project details
    var sql_query = " "
    if (project_ids.length > 0) {
        sql_query = "SELECT id, project_name, user_name FROM Projects WHERE id IN (" + project_ids + ");";
    }
    console.log(sql_query)
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            out +=',"project":' + JSON.stringify(data.rows) + "}"
            console.log(JSON.parse(out))
            res.render('results', { title: 'Results', data: JSON.parse(out), login: req.session.user_name});
        }
    });
});

module.exports = router;

