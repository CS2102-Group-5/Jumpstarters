var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
});

/**SQL Query*/
//get top 3 projects by rating, limited to 3 
var rating_sql = "SELECT p.id FROM Projects p INNER JOIN Rates r ON r.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND h.project_status = 'Ongoing' GROUP BY p.id ORDER BY SUM(r.rating) DESC LIMIT(3);"
//need name, img,description, creator 
var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link FROM Projects p INNER JOIN Media m ON m.project_id = p.id WHERE m.description = 'about' AND p.id IN "

// Check if project has passed and update project status history table
var update_status_sql = "UPDATE History SET project_status = 'Completed' WHERE '"

var update_status = (req, res, next) => {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;
    sql_query = update_status_sql + dateTime + "'> end_date";
    pool.query(sql_query, (err, data) => {
        if(err) {
            console.log(err)
        } else {
            console.log('updated database')
            next();
        }
    });
}

/* GET home page. */
router.get('/', update_status, function (req, res, next) {
    //console.log(req.session);
    var { user_name } = req.session;
    //get top 3 project id 
    pool.query(rating_sql, (err, data) => {
        //console.log(data.rows); 
        var ids = "("
        for (var i = 0; i < data.rows.length; i++) {
            if (i == data.rows.length-1) {
                ids = ids + data.rows[i].id + ');';
            } else {
                ids = ids + data.rows[i].id + ',';
            }
        }
        var sql_query = project_sql + ids;
        //console.log(sql_query);
        pool.query(sql_query, (err, data1) => {
            if (err) {
                console.log(err);
            } else {
                //console.log(data1.rows);
                console.log(req.session.user_name)
                res.render('index', { title: 'JUMPSTARTERS', data: data1.rows, login:req.session.user_name });
            }
        });
    });
  
});

module.exports = router;
