var express = require('express');
var router = express.Router();

const { Pool } = require('pg')

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/**SQL Query*/
//get top 3 projects by rating, limited to 3 
var rating_sql = "SELECT p.id FROM Projects p INNER JOIN Rates r ON r.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND h.project_status = 'Ongoing' GROUP BY p.id ORDER BY SUM(r.rating) DESC, p.project_name LIMIT(3);"
//need name, img,description, creator 
var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link FROM Projects p INNER JOIN Media m ON m.project_id = p.id WHERE m.description = 'about'"
// Check if project has passed and update project status history table
var update_status_sql = "WITH X AS (SELECT h.goal, h.time_stamp, h.project_id, h.project_status FROM History h WHERE (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND h.end_date < CURRENT_TIMESTAMP AND h.project_status = 'Ongoing') UPDATE History h SET project_status = CASE WHEN (SELECT true FROM X INNER JOIN Pledges p ON p.project_id = X.project_id WHERE h.project_id = X.project_id AND h.time_stamp = X.time_stamp HAVING h.goal <= COALESCE(SUM(p.pledge))) THEN 'Successful' WHEN (SELECT true FROM X INNER JOIN Pledges p ON p.project_id = X.project_id WHERE h.project_id = X.project_id AND h.time_stamp = X.time_stamp HAVING h.goal > COALESCE(SUM(p.pledge))) THEN 'Unsuccessful'ELSE 'Ongoing' END WHERE (h.project_id , h.time_stamp) IN (SELECT project_id,time_stamp FROM X);";

var update_status = (req, res, next) => {
    /** 
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;
    */
    pool.query(update_status_sql, (err, data) => {
        if(err) {
            console.log(err)
        } else {
            console.log('updated database')
            next();
        }
    });
}

/* GET home page. */
router.get('/', update_status, function (req, res, next) {
    //console.log(req.session);
    user_name = req.session.user_name;
    country = req.session.country;
    //get top 3 project id 
    console.log(rating_sql)
    pool.query(rating_sql, (err, data) => {
        if (err) {
            console.log('rating')
            res.send(500,{error:err.toString()})
        } else {
            if (data.rows.length == 0) {
                var tail = "LIMIT(3);"
            } else {
                var tail = " AND p.id IN ("
                for (var i = 0; i < data.rows.length; i++) {
                    if (i == data.rows.length-1) {
                        tail = tail + data.rows[i].id + ')LIMIT(3);';
                    } else {
                        tail = tail + data.rows[i].id + ',';
                    }
                }
            }
            var sql_query = project_sql + tail;
            console.log(sql_query)
            pool.query(sql_query, (err, data1) => {
                if (err) {
                console.log('projects')
                res.send(500,{error:err.toString()})
                } else {
                    //get recommended projects
                    //check if preferences is non empty and display recommended projects
                    if (user_name) {
                        var recommend_query = "WITH X AS (SELECT COALESCE(SUM(r.rating),0) as rating, r.project_id  as id FROM Rates r GROUP BY r.project_id UNION SELECT 0 as rating, p.id FROM Projects p WHERE p.id NOT IN (SELECT DISTINCT project_id FROM Rates)) SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, X.rating, p.project_type FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN Funder f ON p.project_type = ANY (f.preferences) INNER JOIN X ON X.id = p.id WHERE m.description = 'about' AND f.user_name = '"+user_name+ "' AND EXISTS (SELECT 1 FROM Shipping_info s where s.project_id = p.id AND country_name = '" + country + "') ORDER BY X.rating DESC, p.project_name LIMIT(3);"
                        console.log(recommend_query)
                        pool.query(recommend_query,(err,data2) => {
                            if (err){
                                res.send(500,{error:err.toString()})
                            } else {
                                res.render('index', {title:'JUMPSTARTERS', data:data1.rows, login:req.session.user_name, rec:data2.rows})
                            }
                        })
                    } else {
                        res.render('index', { title: 'JUMPSTARTERS', data: data1.rows, login:req.session.user_name, rec:[] });
                    }                    
                }
        }   );
        }
        
    });
  
});

module.exports = router;
