var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/* SQL Query */
var sql_query = 'INSERT INTO UserAccount VALUES';

/* GET home page. */
router.get('/', function(req, res, next) {
    var country_list_sql = "SELECT country_name FROM country ORDER BY country_name;"
    pool.query(country_list_sql,(err,data) => {
        if (err) {
            res.send(500,{error:err.toString()})
        } else {
            // replace single quotes with double quotes
            for (var i =0;i<data.rows.length;i++) {
                data.rows[i].country_name = data.rows[i].country_name.replace("'","''")
            }
            res.render('signup', { title: 'Sign up', login: req.session.user_name ,countries:data.rows});
        }
    })
    
});

/* POST */
router.post('/', function (req, res, next) {
    // Retrieve Information
    console.log('In post');
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var acc = req.body.accountType;
    var name = req.body.name;
    var email = req.body.email;
    var country = req.body.country;
    var user = req.body.user;
    var pass = req.body.pass;
    // Construct Specific SQL Query
    if (acc == 'Creator') {
        var organization = req.body.organization;
        var sql = "CALL create_new_creator" + "('" + user + "','" + name + "','" + email + "','" + country + "','" + pass + "','" + organization + "')";
        console.log(sql); 
        pool.query(sql, (err, data) => {
            if (err) {
                res.send(500,{error:err.toString()})
            } else {
                console.log('Inserted into Creator');
                res.redirect('/login');
            }
        });
    }
    if (acc == 'Funder') {
        var preferences = req.body.preferences;
        var sql = "CALL create_new_funder" + "('" + user + "','" + name + "','" + email + "','" + country + "','" + pass + "'," + " ARRAY["
        for (i = 0; i < preferences.length; i ++) {
            if (i == preferences.length - 1) {
                sql = sql + "'" + preferences[i] + "'";
            } else {
                sql = sql + "'" + preferences[i] + "',";
            }
        }
        sql = sql + "]);"
        console.log(sql)
        pool.query(sql, (err, data) => {
            if (err) {
                res.send(500,{error:err.toString()})
            } else {
                console.log('Inserted into Funder');
                res.redirect('/login');
            }
        });
    };
});

module.exports = router;
