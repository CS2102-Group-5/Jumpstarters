var express = require('express');
var session = require('express-session');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

var redirectHome = (req, res, next) => {
    if (req.session.user_name) {
        console.log('You are already logged in');
        res.redirect('/');
    } else {
        next();
    }
}

/* SQL Query */
var sql_select = 'SELECT suspended FROM UserAccount WHERE';
var sql_update = 'UPDATE UserAccount SET last_login = '

/* GET home page. */
router.get('/', redirectHome, function (req, res, next) {
    req.session.past_url = req.headers.referer
    res.render('login', { title: 'Login', login: req.session.user_name });
});

/* POST */
router.post('/', function (req, res, next) {
    var proto = req.protocol + '://' + req.get('host')
    var past_path = req.session.past_url.replace(proto, '')
    // Retrieve Information
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var user = req.body.user;
    var pass = req.body.pass;

    // Construct Specific SQL Query
    var select_query = sql_select + " user_name = '" + user + "' AND password = '" + pass + "';";
    //console.log(select_query);
    var update_query = sql_update + "'" + dateTime + "' WHERE user_name = '" + user + "';";
    pool.query(select_query, (err, data) => {
        if (err) {
            console.log('ERR:' + err);
            console.log('There has been an error, please try again');
        } else {
            console.log(data.rows[0]);
            if (data.rows.length == 1) {
                if (data.rows[0].suspended == true) {
                    //TODO: Add modal, or something to inform the user
                    console.log('Your account has been suspended');
                } else {
                    pool.query(update_query, (err, data) => {
                        if (err) {
                            console.log('ERR: ' + err);
                        }
                        //to be changed
                        console.log(update_query);
                        console.log('successfully logged in!');
                        req.session.user_name = user;
                        if (past_path == '/signup') {
                            res.redirect('/');
                        } else {
                            res.redirect(past_path);
                        }
                        
                    });
                }
            } else {
                console.log('Incorrect Password');
                res.send(500, {error:'Incorrect Password or Username'})
            }
        }
        
    });
});

module.exports = router;