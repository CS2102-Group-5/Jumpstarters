﻿var express = require('express');
var session = require('express-session');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

//redirect 
var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

/* SQL Query */
var sql_comment_insert = 'INSERT INTO Comments VALUES('

/* POST */
router.post('/', redirectLogin, function (req, res, next) {
    // Retrieve Information
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    var id = Url.searchParams.get('id');

    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var user_name = req.session.user_name;
    var comment = req.body.comment;

    // Construct Specific SQL Query
    var sql_query = sql_comment_insert + id + ", '" + user_name + "', '" + comment + "', '" + dateTime + "');";
    console.log(sql_query);
    pool.query(sql_query, (err, data) => {
        if (err) {
            res.send(500, {error:err.toString()})
        } else {
            console.log('Inserted comment')
            req.session.refresh = true
            res.redirect('/viewProject?id=' + id)
        }

    });
});

module.exports = router;