﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})


var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}


router.post('/', redirectLogin, (req, res, next) => {
    console.log('in logout');
    //console.log(req.session.user_name);
    //TODO: Destroy not found need to fix 
    req.session.destroy(function (err) {
        if (err) {
            console.log(err);
        } else {
            //console.log(req.session);
            res.redirect('/');
        }
    })
})

module.exports = router;