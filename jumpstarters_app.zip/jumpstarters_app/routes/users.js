var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/**SQL Query*/
//need name, img,description, creator
var creator_sql = "SELECT true FROM Creator WHERE user_name = '"
var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND p.user_name = '";
var follows_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE (h.project_id,h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND m.description = 'about' AND p.id IN (SELECT projects_followed FROM Follows WHERE Funder = '";
var pledges_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE (h.project_id,h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND m.description = 'about' AND p.id IN (SELECT project_id FROM Pledges WHERE user_name = '";
/* GET home page. */

router.get('/', function (req, res, next) {
    console.log(req.session);
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    user_name = req.session.user_name
    sql_check_creator = creator_sql + user_name + "'";
    pool.query(sql_check_creator, (err, data) => {
        if (err) {
            console.log(err)
            res.redirect('back')
        } else {
            var is_creator = data.rows[0]
            if (is_creator) {
                var sql_query = project_sql + user_name + "' ORDER BY p.project_name;";
                pool.query(sql_query, (err, data1) => {
                    console.log(data1.rows)
                    res.render('users', { title: user_name, data: data1.rows, login: req.session.user_name, creator:is_creator})
                });
            } else {
                var sql_query = follows_sql + user_name + "') ORDER BY p.project_name;";
                var sql_query_pledges = pledges_sql + user_name + "') ORDER BY p.project_name;"
                pool.query(sql_query, (err, data1) => {
                    if (err) {
                        res.send(500,{error:err.toString()})
                    } else {
                        pool.query(sql_query_pledges, (err,data2) => {
                            if (err) {
                                res.send(500,{error:err.toString()})
                            } else {
                                res.render('users', { title: user_name, data: data1.rows, login: req.session.user_name, creator:is_creator, pledges: data2.rows})
                            }
                        })
                    }
                });
            }
        }
    });
});

//redirect 
var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

module.exports = router;
