var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/**SQL Query*/
//get top 3 projects by rating, limited to 3 
var rating_sql = 'SELECT p.id FROM Projects p INNER JOIN Rates r ON r.project_id = p.id GROUP BY p.id ORDER BY SUM(r.rating) DESC LIMIT(3);'
//need name, img,description, creator 
var bad_creator_sql = "WITH X AS (SELECT DISTINCT p.id FROM Projects p WHERE EXISTS (SELECT 1 FROM History h WHERE h.project_id = p.id AND (h.end_date,h.time_stamp) > ANY(SELECT h1.end_date,h1.time_stamp FROM History h1 WHERE h1.project_id = p.id))), Y AS (SELECT DISTINCT p.id FROM Projects p INNER JOIN History h1 ON h1.project_id = p.id INNER JOIN History h2 ON h1.project_id = h2.project_id AND h1.time_stamp > h2.time_stamp AND h1.goal < h2.goal) SELECT u.name,u.email,u.country_name,u.suspended,a.*,(CASE WHEN c.organization IS NULL THEN 1 ELSE 0 END) AS no_organization FROM ( SELECT c.user_name , SUM((SELECT COUNT(*) FROM X WHERE x.id = p.id)) AS num_extended_deadline, SUM((SELECT COUNT(*) FROM Y WHERE y.id = p.id)) AS num_goal_decreased, SUM((SELECT COUNT(*) FROM (SELECT r.project_id as id FROM Rates r INNER JOIN Projects p ON p.id = r.project_id GROUP BY r.project_id HAVING AVG(r.rating) < 2.5) AS Z WHERE z.id = p.id)) AS low_rating_projects FROM Creator c INNER JOIN Projects p ON p.user_name = c.user_name group by c.user_name ) AS a INNER JOIN Creator c ON a.user_name = c.user_name INNER JOIN UserAccount u ON u.user_name = a.user_name WHERE add(num_extended_deadline,num_goal_decreased,low_rating_projects,CASE WHEN c.organization IS NULL THEN 1 ELSE 0 END) > 0 AND u.suspended = false ORDER BY num_extended_deadline DESC, num_goal_decreased DESC, low_rating_projects DESC, 9 DESC;"
var suspended_account_sql = "SELECT u.name,u.email,u.country_name,u.suspended, u.user_name from UserAccount u WHERE u.suspended = true";
var admin_check_sql = "SELECT true FROM Admin WHERE user_name ='"
var suspend_sql = "UPDATE UserAccount SET suspended = true WHERE user_name = '"
var unsuspend_sql = "UPDATE UserAccount SET suspended = false WHERE user_name = '"
/* GET home page. */

var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

router.get('/', redirectLogin, function (req, res, next) {
    // check if user is admin
    user_name = req.session.user_name
    var sql_admin = admin_check_sql + user_name + "'";
    var out = "{";
    pool.query(sql_admin, (err, data) => {
        if (err) {
            console.log(err)
        } else {
            if (!data.rows[0]) {
                console.log('You are not an admin')
                res.redirect('/')
            } else {
                //get bad creators  
                pool.query(bad_creator_sql, (err, data) => {
                    if (err) {
                        console.log(err);
                    } else {
                        out = out + '"bad":' + JSON.stringify(data.rows)
                        console.log(out)
                        pool.query(suspended_account_sql, (err, data1) => {
                            if (err) {
                                console.log(err)
                            } else {                             
                                out = out + ', "suspended": ' + JSON.stringify(data1.rows)
                                out += "}"
                                //console.log(JSON.parse(out))
                                res.render('admin', { title: 'admin', data: JSON.parse(out), login: req.session.user_name })
                            }
                        });
                    }
                });
            }
        }
    })
});

router.post('/', redirectLogin, function (req, res, next) {
    user_name = req.session.user_name
    var sql_admin = admin_check_sql + user_name + "'";
    pool.query(sql_admin, (err, data) => {
        if (err) {
            console.log(err)
        } else {
            if (!data.rows[0]) {
                console.log('You are not an admin')
                res.redirect('/')
            } else {
                //get bad creators
                bad_user = req.body.suspend
                good_user = req.body.unsuspend

                if (bad_user != undefined) {
                    sql_suspend_user = suspend_sql + bad_user + "'";
                    pool.query(sql_suspend_user, (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log(data.rows)
                            console.log(bad_user + ' has been suspended');
                            res.redirect('back');
                        }
                    });
                }
                if (good_user != undefined) {
                    sql_unsuspend_user = unsuspend_sql + good_user + "'";
                    pool.query(sql_unsuspend_user, (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log(data.rows)
                            console.log(good_user + ' has been unsuspended');
                            res.redirect('back');
                        }
                    });
                }
            }
        }
    })
})

module.exports = router;
