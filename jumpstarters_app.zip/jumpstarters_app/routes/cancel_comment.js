﻿var express = require('express');
var session = require('express-session');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

//redirect 
var redirectLogin = (req, res, next) => {
    if (!req.session.user_name) {
        console.log('You are not logged in');
        res.redirect('/login');
    } else {
        next();
    }
}

/* SQL Query */
var sql_comment_delete = 'DELETE FROM Comments WHERE project_id = '

/* POST */
router.post('/', redirectLogin, function (req, res, next) {
    // Retrieve Information
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    var id = Url.searchParams.get('id');
    var user_name = Url.searchParams.get('user') 
    var date = Url.searchParams.get('time_stamp')
    console.log(date)

    // format time_stamp to insert to sql 
    var pad = function (num) { return ('00' + num).slice(-2) }; 
    date = new Date(date);
    console.log(date.toString())
    time_stamp = date.getFullYear() + '-' +
        pad(date.getMonth() + 1) + '-' +
        pad(date.getDate()) + ' ' +
        pad(date.getHours()) + ':' +
        pad(date.getMinutes()) + ':' +
            pad(date.getSeconds());
    console.log(time_stamp)


    // Construct Specific SQL Query
    var sql_query = sql_comment_delete + id + " AND user_name = '" + user_name + "' AND time_stamp = '" + time_stamp + "';";
    console.log(sql_query);
    pool.query(sql_query, (err, data) => {
        if (err) {
            res.send(500, { error: err.toString() })
        } else {
            console.log('Deleted comment')
            req.session.refresh = true
            res.redirect('/viewProject?id=' + id)
        }

    });
});

module.exports = router;