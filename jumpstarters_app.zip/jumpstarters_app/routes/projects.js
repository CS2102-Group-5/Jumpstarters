var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/**SQL Query*/
//need name, img,description, creator  
var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) ORDER BY p.project_name;"
//get projects by project type  
var type_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND p.project_type = "
var tags_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id INNER JOIN tags t ON t.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND t.tag_name = '"
/* GET home page. */

router.get('/', function (req, res, next) {
    user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    //console.log(Url)
    var type = Url.searchParams.get('project_type');
    var tags = Url.searchParams.get('tags');
    console.log(type)
    console.log(tags)
    if (type) {
        sql_query = type_sql + "'" + type + "' ORDER BY p.project_name;"
        //console.log(sql_query) 
        pool.query(sql_query, (err, data) => {
            if (err) {
                console.log(err)
            } else {
                res.render('projects', { title: 'Categories', header: type, data: data.rows, login: req.session.user_name })
            }
        });
    } else if (tags) {
        sql_query = tags_sql + tags + "'";
        console.log(sql_query)
        pool.query(sql_query, (err, data) => {
            if (err) {
                console.log(err)
            } else {
                console.log(data.rows)
                res.render('projects', { title: 'Tags', header: "Tag name: #" + tags, data: data.rows, login: req.session.user_name })
            }
        });
    } else {
        pool.query(project_sql, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.render('projects', { title: 'All Projects', header: 'All Projects', data: data.rows, login: req.session.user_name })
            }
        });
    }
});


module.exports = router;
