var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})

/**SQL Query*/
//need name, img,description, creator  
//var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) ORDER BY p.project_name;"
//var project_sql="SELECT get_projects_info()";
//get projects by project type  
//var type_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND p.project_type = "
//var tags_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id INNER JOIN tags t ON t.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND t.tag_name = '"
/* GET home page. */

router.get('/', function (req, res, next) {
    user_name = req.session.user_name;
    country = req.session.country;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    //retrieve variables
    var type = Url.searchParams.get('project_type');
    var tags = Url.searchParams.get('tags');    
    console.log(type)
    console.log(tags)
    if (type) {
        var type_sql = (user_name) ? "SELECT * FROM get_projects_info_by_type('"+ country +"','"+ type +"');" : "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND p.project_type = '" + type + "' ORDER BY p.project_name;"
        //console.log(sql_query) 
        pool.query(type_sql, (err, data) => {
            if (err) {
                res.send(500,{error:err.toString()})
            } else {
                res.render('projects', { title: 'Categories', header: type, data: data.rows, login: req.session.user_name, country: req.session.country })
            }
        });
    } else if (tags) {
        var tags_sql = (user_name && tags) ? "SELECT * FROM get_projects_info_by_tags('"+ country +"','"+ tags +"');" : "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id INNER JOIN tags t ON t.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) AND t.tag_name = '" + tags + "'ORDER BY p.project_name;";
        console.log(tags_sql)
        pool.query(tags_sql, (err, data) => {
            if (err) {
                res.send(500,{error:err.toString()})
            } else {
                //console.log(data.rows)
                res.render('projects', { title: 'Tags', header: "Tag name: #" + tags, data: data.rows, login: req.session.user_name, country: req.session.country })
            }
        });
    } else {
        var project_sql = (user_name) ? "SELECT * FROM get_projects_info('"+ country +"');" : "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link, h.project_status, h.end_date, p.project_location FROM Projects p INNER JOIN Media m ON m.project_id = p.id INNER JOIN History h ON h.project_id = p.id WHERE m.description = 'about' AND (h.project_id, h.time_stamp) IN (SELECT project_id, MAX(time_stamp) FROM History GROUP BY project_id) ORDER BY p.project_name;"
        console.log(project_sql)
        pool.query(project_sql, (err, data) => {
            if (err) {
                res.send(500,{error:err.toString()})
            } else {
                //console.log(data.rows);
                console.log('Germany' != req.session.country)
                res.render('projects', { title: 'All Projects', header: 'All Projects', data: data.rows, login: req.session.user_name, country: req.session.country })
            }
        });
    }
});


module.exports = router;
