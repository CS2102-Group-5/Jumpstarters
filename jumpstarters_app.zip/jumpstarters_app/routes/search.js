﻿var express = require('express');
var router = express.Router();
var url = require('url');

const { Pool } = require('pg')
const pool = new Pool({
    connectionString: process.env.DATABASE_URL
})


//SQL
//TODO: limit number of rows for project id 
sql_search1 = "SELECT * FROM (SELECT id, count_occurances('"
sql_search2= "', project_description, project_name, user_name) AS rank, project_name FROM projects) AS a WHERE rank > 0 ORDER BY rank DESC, project_name;"

sql_search_type = "SELECT DISTINCT REPLACE(project_type,'&','%26') AS project_type FROM Projects WHERE LOWER(project_type) LIKE LOWER('%"

router.post('/', function(req, res, next) {
    console.log('in search');
    //replace single quotes with double
    var search_text = req.body.search_text.replace("'","''")
    sql_project = sql_search1 + search_text + sql_search2;
    sql_type = sql_search_type + search_text + "%');";
    //console.log(sql_project);
    //console.log(sql_type);
    pool.query(sql_type, (err, data) => {
        var out ="";
        if (err) {
            res.send(500,{error:err.toString()})
        } else {
            console.log('project_type: ' + data.rows)
            out = "?" + format_array(data.rows, 'project_type','project_type');
            console.log(out)
            console.log(sql_project)
            pool.query(sql_project, (err, data1) => {
                if (err) {
                    res.send(500,{error:err.toString()})
                } else {
                    out = (out == "") ? "?" + format_array(data1.rows, 'projects','id') : out + "&" + format_array(data1.rows,'projects','id')
                    console.log(out);
                    res.redirect('/results' + out);
                }
            });
        }
    });
})

//replace special characters '&' with %26 
function format_array(arr, arr_name, attribute) {
    console.log(arr)
    var out =""
    for (var i = 0; i < arr.length; i++) {
        //only replace if its a string
        arr[i][attribute] =  (typeof arr[i][attribute] === 'string') ? arr[i][attribute].replace('&','%26') : arr[i][attribute]
        if (i == arr.length - 1) {
            out = out + arr_name + "[]=" + arr[i][attribute]
        } else {
            out = out + arr_name + "[]=" + arr[i][attribute] + "&"
        }
    }
    return out
}

module.exports = router;
