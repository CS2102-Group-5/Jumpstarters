var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/**SQL Query*/
//get top 3 projects by rating, limited to 3 
var rating_sql = 'SELECT p.id FROM Projects p INNER JOIN Rates r ON r.project_id = p.id GROUP BY p.id ORDER BY SUM(r.rating) DESC LIMIT(3);'
//need name, img,description, creator 
var project_sql = "SELECT p.id, p.user_name, p.project_name, p.project_description, m.link FROM Projects p INNER JOIN Media m ON m.project_id = p.id WHERE m.description = 'about' AND p.id IN "

/* GET home page. */

router.get('/', function (req, res, next) {
    console.log(req.session);
    var { user_name } = req.session;
    //get top 3 project id 
    pool.query(rating_sql, (err, data) => {
        //console.log(data.rows); 
        var ids = "("
        for (var i = 0; i < data.rows.length; i++) {
            if (i == data.rows.length-1) {
                ids = ids + data.rows[i].id + ');';
            } else {
                ids = ids + data.rows[i].id + ',';
            }
        }
        var sql_query = project_sql + ids;
        console.log(sql_query);
        pool.query(sql_query, (err, data1) => {
            if (err) {
                console.log(err);
            } else {
                console.log(data1.rows);
                res.render('admin', { title: 'Admin', data: data1.rows });
            }
        });
    });
  
});

var sql_search = "SELECT p.id FROM Projects p WHERE lower(p.project_name) like lower('%"

router.post('/', function (req, res, next) {
    console.log('in search');
    console.log(req.body);
    console.log(req.session);
    console.log(req.body);
    var search_text = req.body.search_text;
    sql_query = sql_search + search_text + "%')";
    console.log(sql_query)
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err)
        } else {
            if (data.rows.length != 0)
                var project_id = data.rows[0].id
            res.redirect('/viewProject?id=' + project_id);
        }
    });
})


module.exports = router;
