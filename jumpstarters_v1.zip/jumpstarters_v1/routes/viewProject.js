﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})


/* GET home page. */
router.get('/', function (req, res, next) {
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    id = Url.searchParams.get('id');
    /* SQL Query */
    var sql_details = 'SELECT * FROM Projects WHERE id = ' + id + ';';
    var sql_media = 'SELECT link, description FROM Media WHERE project_id = ' + id + ';';
    /** Get latest history */
    var sql_history = 'select h1.*, extract(day from (h1.end_date  - CURRENT_TIMESTAMP)) as days_to_go from history h1 left join history h2 on h1.time_stamp > h2.time_stamp and h2.project_id = h1.project_id where h2.project_id is NULL AND h1.project_id = ' + id + ';';
    var sql_shipping_info = 'select * from shipping_info WHERE project_id = ' + id + ';';
    var sql_total_pledge = 'select COALESCE(SUM(pledge),0) AS total_pledge, COUNT(*) AS backers FROM Pledges WHERE project_id = ' + id + ';';
    var sql_comments = 'select * from Comments WHERE project_id = ' + id + ';';
    var sql_tags = 'select tag_name from tags WHERE project_id = ' + id + ';';
    console.log(sql_details);
  
    
    pool.query(sql_details, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            //remove last character 
            var result = JSON.stringify(data.rows[0]).slice(0, -1) + ',';
            var out = merge(sql_history,sql_media,sql_shipping_info,sql_total_pledge, sql_comments,sql_tags);
            out.then(function (value) {
                result = result + value + "}";
                console.log(JSON.parse(result));
                res.render('viewProject', { data: JSON.parse(result) });
            }) 

        }
    });
});
module.exports = router;

// returns string 
function generate_json(pool, sql, table=undefined) {
    return new Promise((resolve, reject) => {
        pool.query(sql, (err, data) => {
            if (err) {
                reject(err);
            } else {
                if (table == undefined) {
                    resolve(JSON.stringify(data.rows)[0]);
                } else {
                    resolve('"' + table + '": ' + JSON.stringify(data.rows));
                }
            }
        });
    });
}

async function merge(sql_h,sql_m,sql_s,sql_t,sql_c,sql_ta) {
    h = await generate_json(pool, sql_h, 'history');
    m = await generate_json(pool, sql_m, 'media');
    s = await generate_json(pool, sql_s, 'shipping');
    t = await generate_json(pool, sql_t, 'total_pledge');
    c = await generate_json(pool, sql_c, 'comments');
    tags = await generate_json(pool, sql_ta, 'tags');
    //join 
    return h + ',' + m + ',' + s + ',' + t + ',' + c+ ',' + tags;
}