﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})


//SQL

sql_search1 = "SELECT * FROM (SELECT id, count_occurances('"
sql_search2= "', project_description, project_name, project_type) AS rank FROM projects) AS a WHERE rank > 0 ORDER BY rank DESC;"

router.post('/', function(res, req, next) {
    console.log('in search');
    console.log(req.body);
    console.log(req.session);
    console.log(req.body);
    var search_text = req.body.search_text;
    sql_query = sql_search1 + search_text + sql_search2;
    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err)
        } else {
            if (data.rows.length != 0)
                //TODO: return the whole list and display results (maybe in new page or modal)
            var project_id = data.rows[0].id
            res.redirect('/viewProject?id=' + project_id);
        }
    });
})

module.exports = router;