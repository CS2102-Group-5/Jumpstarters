﻿var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* SQL Query */
var sql_insert_pledge = 'INSERT INTO Pledges VALUES(';


/* POST */
router.post('/', function (req, res, next) {
    var user_name = req.session.user_name;
    var Url = new URL(req.protocol + '://' + req.get('host') + req.originalUrl)
    var id = Url.searchParams.get('id');

    // Retrieve Information
    console.log('In post');
    console.log(req);
    console.log(Url);
    //Need to get Creator user_name
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var pledge = req.body.pledge;
    
    //SQL
    sql_query = sql_insert_pledge + id + ",'" + user_name + "'," + pledge + ",'" + dateTime + "');";

    pool.query(sql_query, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            console.log('Inserted pledged to database');
            res.redirect('back');
        }
    });


});

module.exports = router;
