var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* SQL Query */
var get_index = 'SELECT COUNT(*) FROM Projects';
var sql_projects = 'INSERT INTO Projects VALUES';
var sql_history  = 'INSERT INTO History VALUES'
var sql_media = 'INSERT INTO Media VALUES'




/* GET home page. */
router.get('/', function (req, res, next) {
    // Check if user is logged in
    if (!req.session.user_name) {
        console.log('Please log in');
        res.redirect('/login');
    } else {
        //check if user is a creator
        var user_name = req.session.user_name;
        var sql_creator = "SELECT COUNT(*) FROM Creator WHERE user_name = '" + user_name + "';";
        pool.query(sql_creator, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                var is_creator = data.rows[0].count;
                if (is_creator != 1) {
                    console.log('You are not a creator');
                    res.redirect('/');
                } else {
                    res.render('startProject', { title: 'Start A Project' });
                }
            }
        });
    }
});

/* POST */
router.post('/', function (req, res, next) {    
    var user_name = req.session.user_name;

    // Retrieve Information
    console.log('In post');
    //Need to get Creator user_name
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var projectName = req.body.projectName;
    projectName = projectName.replace(/'/,"''");
    var projectType = req.body.projectType;
    var description = req.body.description;
    var start = req.body.projectStart;
    var end = req.body.projectEnd;
    var goal = req.body.goal;
    var country = req.body.country;
    //TODO: add shipping infomation
    //get id for current project
    pool.query(get_index, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            var id = Number(data.rows[0].count) + 1;
             // Construct Specific SQL Query
            //TODO: Get Creator's username
            var insert_projects_query = sql_projects + "(" + id + ",'" + user_name + "','" + projectName + "','" + projectType + "','" + description + "','" + country + "','" + start + "'," + '0' + ")";
            //TODO: make 'Ongoing a variable' 
            var insert_history_query = sql_history + "(" + id + ",'" + 'Ongoing' + "','" + end + "'," + goal + ",'" + dateTime + "')"
            console.log(insert_history_query);
            console.log(insert_projects_query);
            pool.query(insert_projects_query, (err, data) => {
                if (err) {
                    console.log('ERR:' + err);
                } else {
                    console.log('INFO: Inserted into projects');
                    pool.query(insert_history_query, (err, data) => {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log('INFO: Inserted into history');
                            res.redirect('/');
                        }
                    });
                }   
            });
        }
    });
   
    
});

module.exports = router;
