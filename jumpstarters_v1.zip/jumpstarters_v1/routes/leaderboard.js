var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/**SQL Query*/
//get top 3 projects by rating, limited to 3 
var creaters_sql = "WITH CurrentPar AS ( SELECT DISTINCT H1.project_id, prj.user_name, H1.end_date, H1.goal, H1.project_status FROM History H1, Projects prj WHERE NOT EXISTS ( SELECT 1 FROM History H2 WHERE H2.project_id = H1.project_id AND H2.time_stamp > H1.time_stamp ) AND prj.id = H1.project_id ), Stats AS ( SELECT DISTINCT p1.project_id, COALESCE(p1.user_name, r1.user_name, f1.user_name) as user_name, p1.projResult, r1.highRating, f1.num_followers FROM ((SELECT DISTINCT CP.project_id, CP.user_name, CASE WHEN (SUM(P.pledge) >= CP.goal) THEN 1 ELSE 0 END AS projResult FROM Pledges P, CurrentPar CP WHERE P.project_id = CP.project_id AND P.time_stamp <= CP.end_date AND (CP.project_status = 'Ongoing' OR CP.project_status = 'Completed') GROUP BY CP.project_id, CP.user_name, CP.goal) AS p1 FULL OUTER JOIN (SELECT DISTINCT CP.project_id, CP.user_name, CASE WHEN (AVG(R.rating) >= 4.0) THEN 1 ELSE 0 END AS highRating From Rates R, CurrentPar CP WHERE R.project_id = CP.project_id AND (CP.project_status = 'Ongoing' OR CP.project_status = 'Completed') GROUP BY CP.project_id, CP.user_name) AS r1  ON p1.project_id = r1.project_id) FULL OUTER JOIN  (SELECT DISTINCT CP.project_id, CP.user_name, COUNT(F.funder) AS num_followers FROM Follows F, CurrentPar CP WHERE F.projects_followed = CP.project_id AND (CP.project_status = 'Ongoing' OR CP.project_status = 'Completed') GROUP BY CP.project_id, CP.user_name) as f1 ON p1.project_id = f1.project_id ) SELECT S.user_name, U.name, U.email, U.country_name, COALESCE(SUM(projresult), 0) as num_successful_proj, COALESCE((SUM(Cast(highRating as Float))/COUNT(Cast(highRating as Float))), 0) as percent_above_4, COALESCE(SUM(num_followers),0) as total_followers FROM Stats S, UserAccount U WHERE S.user_name = U.user_name GROUP BY S.user_name, U.name, U.email, U.country_name ORDER BY num_successful_proj DESC, percent_above_4 DESC, total_followers DESC, user_name DESC LIMIT(10);"

/* GET home page. */

router.get('/', function (req, res, next) {
    console.log(req.session);
    var { user_name } = req.session;
    //get top 10 creators
    pool.query(creaters_sql, (err, data) => {
        if (err) {
            console.log(err)
        } else {
            console.log(data.rows)
            res.render('leaderboard', {title:'Leaderboard',data:data.rows})
        }
    });
  
});

module.exports = router;
