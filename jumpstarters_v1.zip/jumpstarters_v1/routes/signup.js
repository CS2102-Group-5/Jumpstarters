var express = require('express');
var router = express.Router();

const { Pool } = require('pg')
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Password7!',
    port: 5432,
})

/* SQL Query */
var sql_query = 'INSERT INTO UserAccount VALUES';

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('signup', { title: 'Sign up' });
});

/* POST */
router.post('/', function (req, res, next) {
    // Retrieve Information
    console.log('In post');
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    var acc = req.body.accountType;
    var name = req.body.name;
    var email = req.body.email;
    var country = req.body.country;
    var user = req.body.user;
    var pass = req.body.pass;
    // Construct Specific SQL Query
    var insert_query = sql_query + "('" + user + "','" + name + "','" + email + "','" + country + "','" + pass + "'," + "false,'" + dateTime + "')";
    console.log(insert_query);
    pool.query(insert_query, (err, data) => {
        if (err) {
            console.log('ERR:' + err);
        } else {
            console.log('INFO: User has successfully signed up');
            console.log(acc);
            if (acc == 'Creator') {
                var organization = req.body.organization;
                var sql = "INSERT INTO Creator VALUES('" + user + "','" + organization + "');";
                console.log(sql); 
                pool.query(sql, (err, data) => {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log('Inserted into Creator');
                        res.redirect('/login');
                    }
                });
            }
            if (acc == 'Funder') {
                var preferences = req.body.preferences;
                sql = "INSERT INTO Funder VALUES('" + user + "', ARRAY["
                for (i = 0; i < preferences.length; i ++) {
                    if (i == preferences.length - 1) {
                        sql = sql + "'" + preferences[i] + "'";
                    } else {
                        sql = sql + "'" + preferences[i] + "',";
                    }
                }
                sql = sql + "]);"
                pool.query(sql, (err, data) => {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log('Inserted into Funder');
                        res.redirect('/login');
                    }
                });
            }
        } 
    });
});

module.exports = router;
